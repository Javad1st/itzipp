
<?php 

session_start();
?>
<?php 
include './database/db.php';

// دریافت سه مقاله آخر
$select = $conn->prepare("SELECT * FROM blogs ORDER BY id DESC LIMIT 3");
$select->execute();
$blogs = $select->fetchAll(PDO::FETCH_ASSOC);
?>

<?php 
include './database/db.php';

// دریافت سه مقاله آخر
$select = $conn->prepare("SELECT * FROM blogs ORDER BY id ASC LIMIT 8");
$select->execute();
$blogs = $select->fetchAll(PDO::FETCH_ASSOC);
?>









<!DOCTYPE html>
<html lang="en" dir="rtl">

<head>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="loading.css">
  <link rel="stylesheet" href="Image Slider on Website/style.css">
  <link rel="stylesheet" href="blogbox.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
  <link rel="stylesheet" href="mobile2.css">
<link rel="shortcut icon" href="./tasavir/Untitled-2.png" type="image/x-icon">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>myITLand</title>
</head>

<body>
  <div class="container">
    <!-- صفحه لودینگ -->
    <div id="loading">
      <div id="loading-text"><div class="ring">ITLand
        <span id="span1" ></span>
      </div></div>
    </div>
    <!-- محتوای صفحه اصلی -->
    <div class="gradient">
      
    </div>
    <STYLE>
    .modal {
  position: fixed;
  bottom: 20px;
  right: 20px;
  background-color: rgba(20, 24, 32, 0.97);
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  padding: 20px;
  display: none;
  z-index: 1000;
  width:260px;
  color:white;
}
.close-btn {
position: relative;
width : 10px;
height : 10px;
  cursor: pointer;
  color: red;
  float: right;
}
.close-btn svg{
position: absolute;
top: -10px;
right: -10px;
}
.link-btn {
  margin-right:72px;
  display: none;
  margin-top: 10px;
  padding: 10px;
  background-color:rgb(0, 131, 44);
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

@media  screen  and (max-width : 550px){

  .modal{
    opacity: 0%;
    z-index: -10;
  }
  }
    </style>



<div class="modal" id="myModal">
    <span class="close-btn" id="closeBtn"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgba(255, 0, 0, 0.75);transform: ;msFilter:;"><path d="M16 2H8C4.691 2 2 4.691 2 8v13a1 1 0 0 0 1 1h13c3.309 0 6-2.691 6-6V8c0-3.309-2.691-6-6-6zm4 14c0 2.206-1.794 4-4 4H4V8c0-2.206 1.794-4 4-4h8c2.206 0 4 1.794 4 4v8z"></path><path d="M15.292 7.295 12 10.587 8.708 7.295 7.294 8.709l3.292 3.292-3.292 3.292 1.414 1.414L12 13.415l3.292 3.292 1.414-1.414-3.292-3.292 3.292-3.292z"></path></svg></span>
    <p>
      <br>
    هوش مصنوعی آیتی لند را امتحان کن!
    </p>
    <button class="link-btn" id="linkBtn">!بزن بریم</button>
</div>

<script>
    window.onload = function() {
        const modal = document.getElementById('myModal');
        const closeBtn = document.getElementById('closeBtn');
        const linkBtn = document.getElementById('linkBtn');

        // نمایش مودال بعد از 5 ثانیه
        setTimeout(() => {
            modal.style.display = 'block';
        }, 5000);

        // نمایش دکمه لینک بعد از 5 ثانیه
        setTimeout(() => {
            linkBtn.style.display = 'block';
        }, 5000);

        // بستن مودال با دکمه بستن
        closeBtn.onclick = function() {
            modal.style.display = 'none';
        }

        // رفتن به لینک
        linkBtn.onclick = function() {
            window.location.href = 'ai.php'; // لینک مورد نظر خود را اینجا قرار دهید
        }

        // بستن مودال بعد از 2 دقیقه
        setTimeout(() => {
            modal.style.display = 'none';
        }, 120000);
    }
</script>
    <?php

    require_once('header.php');
    ?>
    <div class="space">
    
    </div>
  </div>
  <div class="searchMain">
    
  <?php
// اتصال به پایگاه داده
include './database/db.php';

// بررسی پارامتر جستجو
if (isset($_GET['query'])) {
    $query = htmlspecialchars($_GET['query']);  // جلوگیری از حملات XSS

    // جستجو در پایگاه داده
    $stmt = $conn->prepare("SELECT * FROM blogs WHERE title LIKE :query");
    $stmt->bindValue(':query', "%" . $query . "%", PDO::PARAM_STR);
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // نمایش نتایج جستجو
    if ($results) {
        echo "<div class='results-container'>";  // اضافه کردن کلاس برای کادر نتایج
        foreach ($results as $result) {
            echo "<div class='result-card'>";  // کادر هر نتیجه
            echo "<h2><a href='maqale ha/blog/index.php?id=" . $result['id'] . "'>" . htmlspecialchars($result['title']) . "</a></h2>";
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<p>نتیجه‌ای یافت نشد.</p>";
    }
}
?>

  <h2 class="title"> دنبال چه میگردی </h2>

        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

        <form id="searchForm">
    <input type="search" id="search-input" name="query" placeholder="جستجو..." autofocus required  autocomplete="off" >
    <i class="fa fa-search"></i>
    <div class='results-container'>
    <div id="results"></div>
    </div>
</form>
        </div>
<script>
    // تابع برای ارسال درخواست جستجو به سرور
    function performSearch(query) {
        const xhr = new XMLHttpRequest();
        xhr.open("GET", "search.php?query=" + encodeURIComponent(query), true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // نمایش نتایج در div#results
                document.getElementById('results').innerHTML = xhr.responseText;
            }
        };
        xhr.send();
    }

    // اضافه کردن رویداد input برای جستجوی آنی
    document.getElementById("search-input").addEventListener("input", function(event) {
        const query = event.target.value.trim();
        
        // اگر ورودی خالی نباشد، جستجو را شروع می‌کنیم
        if (query !== "") {
            performSearch(query); // جستجو را با هر تغییر وارد شده شروع می‌کنیم
        } else {
            document.getElementById('results').innerHTML = ''; // اگر ورودی خالی باشد، نتایج را پاک می‌کنیم
        }
    });

    // جلوگیری از ارسال فرم و رفرش صفحه (در صورت فشردن اینتر)
    document.getElementById('searchForm').addEventListener('submit', function(e) {
        e.preventDefault(); // جلوگیری از ارسال فرم
    });
</script>

        <script>
          
const clearInput = () => {
  const input = document.getElementsByTagName("input")[0];
  input.value = "";
}



        </script>
  <style>

.card {
            border: 1px solid #ccc;
            padding: 20px;
            background-color: #fff;
            margin: 20px 0;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    /* استایل کادر نتایج جستجو */
    .results-container {
      display: none;
        margin-top: 40px;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 8px;
        background-color: #f9f9f9;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        max-height: 400px; /* حداکثر ارتفاع کادر */
        overflow-y: auto; /* اگر نتایج زیاد باشد، اسکرول می‌شود */
    }

    /* استایل برای هر نتیجه */
    .result-card {
        margin-bottom: 10px;
    }

    .result-card h2 {
        font-size: 16px;
        margin: 0;
        color: #333;
    }

    .result-card a {
        text-decoration: none;
        color: #007BFF;  /* رنگ لینک */
    }

    .result-card a:hover {
        text-decoration: underline;  /* هنگام هاور کردن لینک */
    }

    .result-card hr {
        border: none;
        border-top: 1px solid #eee;
        margin: 10px 0;
    }
</style>
  <div id="base" class="baseOf">
    <img class="moon" src="svgHa/b8420a7ec558f6cd2e796a3fabffa775.png" alt="">
    <img class="moon2" src="svgHa/—Pngtree—hazy and beautiful halo moon_5336588.png" alt="">
    <div class="bigPicture">
      <img class="img1" src="svgHa/ITLand.png" alt="">
      <img class="jazir" src="svgHa/jazir.png" alt="">
      <img class="img2 disNone" src="svgHa/ITLand2.png" alt="">
      <div class="bigText">
        <h2>سایت مقاله ای آیتی لند</h2>
        <p>مقالات رایگان و بروز برنامه نویسی در دنیا با آیتی لند</p>
        <a style="font-weight: 900;" href="#slider" class="bigText1">اسکرول کنید
          <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="3 0 17 17"
          style="fill: var(--text-color);  border-radius: 50%;">
          <path d="M16.293 9.293 12 13.586 7.707 9.293l-1.414 1.414L12 16.414l5.707-5.707z"></path>
        </svg>
      </a>
      <a href="./maqale ha/maqale.php"><button style="background-color: green; padding: 10px; border-radius: 10px; color: white; cursor: pointer; " class="blogha" id="blogha"  >برای مشاهده تمامی مقالات کلیک کنید</button></a>
    </div>
  </div>



  <h1 class="title">مقالات پیشنهادی</h1>
  <div class="primarySection">
    <div id="slider" class="slider block">
      <section class="main swiper mySwiper">
        <div class="wrapper swiper-wrapper">
            <?php foreach (array_slice($blogs, 0, 3) as $blog): ?>
            <div class="slide swiper-slide">
            <img src="./uploads/<?= ($blog['image']) ?>" alt="تصویر مقاله" class="image" />
            <div class="image-data">
            <h2 class="sliderText">
                            <?= htmlspecialchars($blog['title']) ?>
                        </h2>
                        <a href="maqale ha/blog/index.php?id=<?= $blog['id'] ?>" class="button">ادامه</a>
               </div>
            </div>
            <?php endforeach; ?>
          </div>

          <div class="swiper-button-next nav-btn"></div>
          <div class="swiper-button-prev nav-btn"></div>
          <div class="swiper-pagination"></div>
        </section>
        
        <!-- Swiper JS -->
        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
        
        <!-- Initialize Swiper -->
        <script>
          var swiper = new Swiper(".mySwiper", {
            slidesPerView: 1,
            loop: true,
            pagination: {
              el: ".swiper-pagination",
              clickable: true,
            },
            navigation: {
              nextEl: ".swiper-button-next",
              prevEl: ".swiper-button-prev",
            },
          });
        </script>
      </div>

        
        <!-- Swiper JS -->
      </div>
    </div>
   
      <h1 class="title">مقالات اخیر</h1>
      
      
      <div class="blogs block">
      <a id="all" href="./maqale ha/maqale.php"><h1>مشاهده همه<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill:var(--secondary-text);"><path d="M12.707 17.293 8.414 13H18v-2H8.414l4.293-4.293-1.414-1.414L4.586 12l6.707 6.707z"></path></svg> </h1></a>
        <?php function limit_words($string, $word_limit)
{
    $words = explode(" ",$string);
    return implode(" ",array_splice($words,0,$word_limit));
} foreach ($blogs as $blog): 


    $rowcoment = $conn->prepare("SELECT COUNT(*) FROM coment WHERE post = ? ");
    $rowcoment->bindValue(1, $blog['id'], PDO::PARAM_INT);
    $rowcoment->execute();
    $count = $rowcoment->fetchColumn(); // استفاده از fetchColumn برای شمارش
    
?>
             <div class="blog">
                <img src="./uploads/<?= ($blog['image']) ?>" alt="تصویر مقاله" class="article-image">
             <h2>  <a href="./maqale ha/blog/index.php?id=<?=$blog['id'] ?>"><?= htmlspecialchars($blog['title']) ?></a></h2> 
                <div class="discreption">
                    <?php
                     

                     
                     
                     
                     $content = $blog['caption'];
                     
                     
                     echo   limit_words($content,5); 
                     
                     ?>
                </div>
                <div class="catSec">

                    <div class="writer">
                        نویسنده: <?= htmlspecialchars($blog['writer']) ?>
                    </div>

                    <div class="categ"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" ><path d="M11 10H9v3H6v2h3v3h2v-3h3v-2h-3z"></path><path d="M4 22h12c1.103 0 2-.897 2-2V8c0-1.103-.897-2-2-2H4c-1.103 0-2 .897-2 2v12c0 1.103.897 2 2 2zM4 8h12l.002 12H4V8z"></path><path d="M20 2H8v2h12v12h2V4c0-1.103-.897-2-2-2z"></path></svg> <p><?= $blog['tags']?></p>  </div>

                </div>
                <div class="iconsSec">

                    <div class="icons">
                    <div class="like icon like-button" id="like-button-0">
       <p id="like-count-0"> 0 </p> 
       <svg id="like-icon-0"  xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
           <path d="M12 4.595a5.904 5.904 0 0 0-3.996-1.558 5.942 5.942 0 0 0-4.213 1.758c-2.353 2.363-2.352 6.059.002 8.412l7.332 7.332c.17.299.498.492.875.492a.99.99 0 0 0 .792-.409l7.415-7.415c2.354-2.354 2.354-6.049-.002-8.416a5.938 5.938 0 0 0-4.209-1.754A5.906 5.906 0 0 0 12 4.595zm6.791 1.61c1.563 1.571 1.564 4.025.002 5.588L12 18.586l-6.793-6.793c-1.562-1.563-1.561-4.017-.002-5.584.76-.756 1.754-1.172 2.799-1.172s2.035.416 2.789 1.17l.5.5a.999.999 0 0 0 1.414 0l.5-.5c1.512-1.509 4.074-1.505 5.584-.002z"/>
       </svg>
       <svg id="liked-icon-0" xmlns="http://www.w3.org/2000/svg" fill="red" width="24" height="24" viewBox="0 0 24 24" style="display: none;">
           <path d="M20.205 4.791a5.938 5.938 0 0 0-4.209-1.754A5.906 5.906 0 0 0 12 4.595a5.904 5.904 0 0 0-3.996-1.558 5.942 5.942 0 0 0-4.213 1.758c-2.353 2.363-2.352 6.059.002 8.412L12 21.414l8.207-8.207c2.354-2.353 2.355-6.049-.002-8.416z"></path>
       </svg>
    </div>
    
    
    
    
    
    
    
    
    <div class="comment icon"><?=$count ?> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style=";transform: ;msFilter:;"><path d="M20 2H4c-1.103 0-2 .897-2 2v18l5.333-4H20c1.103 0 2-.897 2-2V4c0-1.103-.897-2-2-2zm0 14H6.667L4 18V4h16v12z"></path><circle cx="15" cy="10" r="2"></circle><circle cx="9" cy="10" r="2"></circle></svg></div>
                    </div>
                    <div class="save icons">
    <div class="saveIcon icon" data-id="<?= $blog['id'] ?>">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
            <path d="M18 2H6c-1.103 0-2 .897-2 2v18l8-4.572L20 22V4c0-1.103-.897-2-2-2zm0 16.553-6-3.428-6 3.428V4h12v14.553z"></path>
        </svg>
    </div>
    <div class="savedIcon icon" data-id="<?= $blog['id'] ?>" style="display: none;">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
            <path d="M19 10.132v-6c0-1.103-.897-2-2-2H7c-1.103 0-2 .897-2 2V22l7-4.666L19 22V10.132z"></path>
        </svg>
    </div>
</div>

<script>
    // گرفتن همه آیکون‌های ذخیره و ذخیره‌شده
    const saveIcons = document.querySelectorAll('.saveIcon');
    const savedIcons = document.querySelectorAll('.savedIcon');

    // به‌روزرسانی وضعیت آیکون‌ها بر اساس localStorage
    function updateIcons() {
        saveIcons.forEach(saveIcon => {
            const articleId = saveIcon.dataset.id;
            const isSaved = localStorage.getItem(`isSaved-${articleId}`) === 'true';
            const savedIcon = document.querySelector(`.savedIcon[data-id="${articleId}"]`);

            if (isSaved) {
                saveIcon.style.display = "none";
                savedIcon.style.display = "flex";
            } else {
                saveIcon.style.display = "flex";
                savedIcon.style.display = "none";
            }
        });
    }

    // به‌روزرسانی وضعیت آیکون‌ها در بارگذاری صفحه
    updateIcons();

    // افزودن رویداد به هر آیکون ذخیره
    saveIcons.forEach(saveIcon => {
        const articleId = saveIcon.dataset.id;
        const savedIcon = document.querySelector(`.savedIcon[data-id="${articleId}"]`);

        saveIcon.addEventListener("click", () => {
            saveIcon.style.display = "none";
            savedIcon.style.display = "flex";
            localStorage.setItem(`isSaved-${articleId}`, 'true'); // ذخیره وضعیت
        });

        savedIcon.addEventListener("click", () => {
            savedIcon.style.display = "none";
            saveIcon.style.display = "flex";
            localStorage.setItem(`isSaved-${articleId}`, 'false'); // ذخیره وضعیت
        });
    });
</script>
                </div>
                
                <a href="maqale ha/blog/index.php?id=<?=$blog['id'] ?>">
                <div class="view">مشاهده</div>
                 </a>
                
            </div>
        <?php endforeach; ?>
      
    </div>
    </div>
      
    
    <div id="category" class="addMaqaleh block">
      <h2 class="addText">درباره مقالات</h2>
      <div class="addContents">
        <div class="addContent rules">
          <p id="Mcontent">قوانین
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: var(--accent-color);"><path d="M11.178 19.569a.998.998 0 0 0 1.644 0l9-13A.999.999 0 0 0 21 5H3a1.002 1.002 0 0 0-.822 1.569l9 13z"></path></svg>
        </p>
        <span class="Mtexts ">هرگونه کپی برداری از مقالات و منتشر کردن مقاله بدون ذکر منبع ممنوع میباشد</span>
      </div>
      <div class="addContent learn">
        <p id="Lcontent">آموزش
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: var(--accent-color);"><path d="M11.178 19.569a.998.998 0 0 0 1.644 0l9-13A.999.999 0 0 0 21 5H3a1.002 1.002 0 0 0-.822 1.569l9 13z"></path></svg>
      </p>
      <span class="Ltexts "> برای خواندن مؤثر مقاله، ابتدا عنوان و چکیده را بررسی کنید، سپس به دقت متن را بخوانید و نکات کلیدی را یادداشت کنید. </span>
    </div>
  </div>
</div>
</div>
</footer>
</div>

<footer>

<div class="foot foot1">

  <div class="footerSection footerSection1">
  <h1>درباره ما</h1>
  <p> سایت آیتی‌لند در آبان 1402 با هدف ارائه خدمات نوین فناوری و آموزش‌های به‌روز در دنیای آی‌تی راه‌اندازی شد.
در آیتی‌لند، مرزهای دانش را جستجو می‌کنیم و تلاش داریم پلی باشیم بین شما و آینده تکنولوژی.
با ما همراه باشید تا در دنیای دیجیتال پیشرو باشید!
</p>
  </div>

  <div class="footerSection footerSection2">
    <h1>ارتباط با ما</h1>

    <ul>
      <li> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgb(35, 124, 207);"><path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 4.7-8 5.334L4 8.7V6.297l8 5.333 8-5.333V8.7z"></path></svg>info@myitland.ir</li>
      <li><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgb(35, 124, 207)"><path d="m20.665 3.717-17.73 6.837c-1.21.486-1.203 1.161-.222 1.462l4.552 1.42 10.532-6.645c.498-.303.953-.14.579.192l-8.533 7.701h-.002l.002.001-.314 4.692c.46 0 .663-.211.921-.46l2.211-2.15 4.599 3.397c.848.467 1.457.227 1.668-.785l3.019-14.228c.309-1.239-.473-1.8-1.282-1.434z"></path></svg>myitland@</li>
    </ul>
  </div>

  <div class="footerSection footerSection3">
  <h1>محبوب ترین ها</h1>

<ul>
  <li> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgb(228, 185, 28);"><path d="M21.947 9.179a1.001 1.001 0 0 0-.868-.676l-5.701-.453-2.467-5.461a.998.998 0 0 0-1.822-.001L8.622 8.05l-5.701.453a1 1 0 0 0-.619 1.713l4.213 4.107-1.49 6.452a1 1 0 0 0 1.53 1.057L12 18.202l5.445 3.63a1.001 1.001 0 0 0 1.517-1.106l-1.829-6.4 4.536-4.082c.297-.268.406-.686.278-1.065z"></path></svg> <p>روانشناسی رنگ ها</p> </li>
  <li> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgb(228, 185, 28)"><path d="M21.947 9.179a1.001 1.001 0 0 0-.868-.676l-5.701-.453-2.467-5.461a.998.998 0 0 0-1.822-.001L8.622 8.05l-5.701.453a1 1 0 0 0-.619 1.713l4.213 4.107-1.49 6.452a1 1 0 0 0 1.53 1.057L12 18.202l5.445 3.63a1.001 1.001 0 0 0 1.517-1.106l-1.829-6.4 4.536-4.082c.297-.268.406-.686.278-1.065z"></path></svg> <p>اينده برنامه نویسی</p></li>
</ul>
  </div>

</div>




<div class="foot foot2">

<div class="footSec">
  <hr>
  <img src="tasavir/Untitled-2.png" alt="">
  <hr>
</div>
<div class="footSec">

  <ul>
    <li><a href="google.com">
    <svg viewBox="0 0 24 24"  xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
    style="fill: rgba(255, 255, 255, 1);"> <path d="m5.968 23.942a6.624 6.624 0 0 1 -2.332-.83c-1.62-.929-2.829-2.593-3.217-4.426-.151-.717-.17-1.623-.15-7.207.019-6.009.005-5.699.291-6.689.142-.493.537-1.34.823-1.767 1.055-1.57 2.607-2.578 4.53-2.943.384-.073.94-.08 6.056-.08 6.251 0 6.045-.009 7.066.314a6.807 6.807 0 0 1 4.314 4.184c.33.937.346 1.087.369 3.555l.02 2.23-.391.268c-.558.381-1.29 1.06-2.316 2.15-1.182 1.256-2.376 2.42-2.982 2.907-1.309 1.051-2.508 1.651-3.726 1.864-.634.11-1.682.067-2.302-.095-.553-.144-.517-.168-.726.464a6.355 6.355 0 0 0 -.318 1.546l-.031.407-.146-.03c-1.215-.241-2.419-1.285-2.884-2.5a3.583 3.583 0 0 1 -.26-1.219l-.016-.34-.309-.284c-.644-.59-1.063-1.312-1.195-2.061-.212-1.193.34-2.542 1.538-3.756 1.264-1.283 3.127-2.29 4.953-2.68.658-.14 1.818-.177 2.403-.075 1.138.198 2.067.773 2.645 1.639.182.271.195.31.177.555a.812.812 0 0 1 -.183.493c-.465.651-1.848 1.348-3.336 1.68-2.625.585-4.294-.142-4.033-1.759.026-.163.04-.304.031-.313-.032-.032-.293.104-.575.3-.479.334-.903.984-1.05 1.607-.036.156-.05.406-.034.65.02.331.053.454.192.736.092.186.275.45.408.589l.24.251-.096.122a4.845 4.845 0 0 0 -.677 1.217 3.635 3.635 0 0 0 -.105 1.815c.103.461.421 1.095.739 1.468.242.285.797.764.886.764.024 0 .044-.048.044-.106.001-.23.184-.973.326-1.327.423-1.058 1.351-1.96 2.82-2.74.245-.13.952-.47 1.572-.757 1.36-.63 2.103-1.015 2.511-1.305 1.176-.833 1.903-2.065 2.14-3.625.086-.57.086-1.634 0-2.207-.368-2.438-2.195-4.096-4.818-4.37-2.925-.307-6.648 1.953-8.942 5.427-1.116 1.69-1.87 3.565-2.187 5.443-.123.728-.169 2.08-.093 2.75.193 1.704.822 3.078 1.903 4.156a6.531 6.531 0 0 0 1.87 1.313c2.368 1.13 4.99 1.155 7.295.071.996-.469 1.974-1.196 3.023-2.25 1.02-1.025 1.71-1.88 3.592-4.458 1.04-1.423 1.864-2.368 2.272-2.605l.15-.086-.019 3.091c-.018 2.993-.022 3.107-.123 3.561-.6 2.678-2.54 4.636-5.195 5.242l-.468.107-5.775.01c-4.734.008-5.85-.002-6.19-.056z"/></svg></a></li>
          <li><a href="google.com"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
            style="fill: rgba(255, 255, 255, 1);">
            <path
            d="m18.73 5.41-1.28 1L12 10.46 6.55 6.37l-1.28-1A2 2 0 0 0 2 7.05v11.59A1.36 1.36 0 0 0 3.36 20h3.19v-7.72L12 16.37l5.45-4.09V20h3.19A1.36 1.36 0 0 0 22 18.64V7.05a2 2 0 0 0-3.27-1.64z">
          </path>
        </svg></a></li>
        <li><a href="google.com"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
          style="fill: rgba(255, 255, 255, 1);">
          <path
          d="M20.947 8.305a6.53 6.53 0 0 0-.419-2.216 4.61 4.61 0 0 0-2.633-2.633 6.606 6.606 0 0 0-2.186-.42c-.962-.043-1.267-.055-3.709-.055s-2.755 0-3.71.055a6.606 6.606 0 0 0-2.185.42 4.607 4.607 0 0 0-2.633 2.633 6.554 6.554 0 0 0-.419 2.185c-.043.963-.056 1.268-.056 3.71s0 2.754.056 3.71c.015.748.156 1.486.419 2.187a4.61 4.61 0 0 0 2.634 2.632 6.584 6.584 0 0 0 2.185.45c.963.043 1.268.056 3.71.056s2.755 0 3.71-.056a6.59 6.59 0 0 0 2.186-.419 4.615 4.615 0 0 0 2.633-2.633c.263-.7.404-1.438.419-2.187.043-.962.056-1.267.056-3.71-.002-2.442-.002-2.752-.058-3.709zm-8.953 8.297c-2.554 0-4.623-2.069-4.623-4.623s2.069-4.623 4.623-4.623a4.623 4.623 0 0 1 0 9.246zm4.807-8.339a1.077 1.077 0 0 1-1.078-1.078 1.077 1.077 0 1 1 2.155 0c0 .596-.482 1.078-1.077 1.078z">
        </path>
        <circle cx="11.994" cy="11.979" r="3.003"></circle>
      </svg></a></li>
      <li><a href="google.com"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" style="fill: rgba(255, 255, 255, 1);transform: ;msFilter:;"><path d="m20.665 3.717-17.73 6.837c-1.21.486-1.203 1.161-.222 1.462l4.552 1.42 10.532-6.645c.498-.303.953-.14.579.192l-8.533 7.701h-.002l.002.001-.314 4.692c.46 0 .663-.211.921-.46l2.211-2.15 4.599 3.397c.848.467 1.457.227 1.668-.785l3.019-14.228c.309-1.239-.473-1.8-1.282-1.434z"></path></svg></a></li>
      </ul>
</div>

</div>

<div class="foot foot3">
  <p style="color:rgba(255, 255, 255, 0.61); text-align:center;">
  کليه حقوق و محتوای اين سایت متعلق به آیتی لند می باشد و هر گونه کپی برداری از محتوا سایت غیر مجاز و بدون رضایت ماست
www.Myitland.ir</p></div>
    </footer>
    
    
    
  </div>
  
  
  <script type="text/javascript" src="darkmode.js"></script>
  <script src="script.js"></script>
  <script src="maqale ha/script.js"></script>
 
</body>

</html>